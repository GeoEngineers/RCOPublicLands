INSERT INTO todo_item(id, description, status)
VALUES (44, 'Get groceries', 'Incomplete');

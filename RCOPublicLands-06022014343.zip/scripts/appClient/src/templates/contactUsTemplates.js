﻿MainApplication.Templates = MainApplication.Templates || {};
MainApplication.Templates.ContactUsView = [
    "<br/><br/><span style=\"color: #25AAE1; font-size: 12pt; margin-top: 20px\">Thank you for contacting MainApplication.  You can reach us either by phone or e-mail below.</span>",
    "<br/><br/><h3>Phone:</h3>",
    "<p style=\"margin: 10px\">",
        "<span class=\"label\">Main:</span>",
        "<span>253-271-4152</span>",
    "</p>",
    "<div>",
        "<h3>Email:</h3>",
        "<p style=\"margin: 10px\">",
        "<span class=\"label\">Support:</span>",
        "<span><a href=\"mailto:support@MainApplication.com\">Support@MainApplication.com</a></span>",
        "</p>",
        "<p style=\"margin: 10px\">",
        "<span class=\"label\">General:</span>",
        "<span><a href=\"mailto:MainApplication@smartmine.com\"> MainApplication@smartmine.com</a></span>",
        "</p>",
    "</div>",
    "<br/><br/>"
].join("\n");
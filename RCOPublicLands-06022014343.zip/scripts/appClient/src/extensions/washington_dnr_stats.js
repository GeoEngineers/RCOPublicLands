BootstrapVars = {} || BootstrapVars;
BootstrapVars.dnrStats = {
  "agency": "Washington Department of Natural Resources",
  "total_acres" : "912984.589506"
};
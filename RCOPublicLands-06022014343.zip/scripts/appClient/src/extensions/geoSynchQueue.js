GeoAppBase.syncQueue = {};
_.extend(GeoAppBase.syncQueue, { 
	init: function(){
		console.log("Active");
	}
});
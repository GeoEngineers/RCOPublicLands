var target = require('./../todoModels.js');

describe('todoModels', function(){
	
	it('should log the interface', function(done){
		console.log(target);
		done();
	});
	
});
//var todoPgToSqlite = require('./../todoPgToSqlite.js');

// this test should be re-written to mocha
// this should happen when we complete this feature
// currently we don't know that this feature will be implemented further

// todoPgToSqlite.snapshotDatabase()
	// .ensure(process.exit);